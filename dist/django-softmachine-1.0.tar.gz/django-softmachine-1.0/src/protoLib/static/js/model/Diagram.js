/**
 * @author Giovanni Victorette
 */
Ext.define('ProtoUL.model.Diagram', {
    extend: 'Ext.data.Model',
    fields: ['projectID','id', 'code', 'smUUID']
});