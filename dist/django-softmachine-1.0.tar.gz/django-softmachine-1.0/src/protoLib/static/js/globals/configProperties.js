/**
 * @author Giovanni Victorette
 */

_SM._requiredField = '<span style="color:red;font-weight:bold" data-qtip="Required">*</span>';

_SM._versionProto = 'Version 1.0.2';
_SM._siteTitle = '<span class="title"> CeRTAE </span><br><span class="subtitle">' + _SM._versionProto + '</span>';

_SM.loginTitle = 'Identification';
_SM._siteTitleCollapsed = false;

_SM.showFooterExtraContent = false;
_SM.footerExtraContent = '<div class="centre">' +
	'<div id="pied">'+
	'</div>'+
'</div>';

_SM._HELPpath = 'static/help/index.html';