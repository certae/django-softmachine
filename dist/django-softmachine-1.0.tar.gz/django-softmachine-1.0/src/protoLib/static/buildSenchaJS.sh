#!/bin/bash

sencha build -p app.jsb3 -d .